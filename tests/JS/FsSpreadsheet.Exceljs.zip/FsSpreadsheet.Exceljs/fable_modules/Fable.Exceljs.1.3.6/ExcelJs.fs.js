import base_xform from "exceljs/lib/xlsx/xform/base-xform.js";
import exceljs from "exceljs";

export const PatchExcelJs_BaseXform = base_xform;

export function PatchExcelJs_patch(obj) {
        obj.prototype.parse = async function(saxParser){
      for await (const events of saxParser) {
        for (const {eventType, value} of events) {
          if(value.name && value.name.startsWith('x:')) value.name = value.name.slice(2);

          if (eventType === 'opentag') {
            this.parseOpen(value);
          } else if (eventType === 'text') {
            this.parseText(value);
          } else if (eventType === 'closetag') {
            if (!this.parseClose(value.name)) {
              return this.model;
            }
          }
        }
      }
      return this.model;
    };
}

PatchExcelJs_patch(PatchExcelJs_BaseXform);

export const Excel = exceljs;

