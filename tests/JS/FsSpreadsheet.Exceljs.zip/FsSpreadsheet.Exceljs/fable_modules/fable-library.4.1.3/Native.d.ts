import { int32 } from "./Int32.js";
export declare function Helpers_allocateArrayFromCons<T>(cons: any, len: int32): T[];
