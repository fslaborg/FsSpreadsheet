import { startAsPromise } from "./fable_modules/fable-library.4.1.3/Async.js";
import { singleton } from "./fable_modules/fable-library.4.1.3/AsyncBuilder.js";
import { Excel } from "./fable_modules/Fable.Exceljs.1.3.6/ExcelJs.fs.js";
import { toJsWorkbook, toFsWorkbook } from "./Workbook.fs.js";
import { class_type } from "./fable_modules/fable-library.4.1.3/Reflection.js";

export class Xlsx {
    constructor() {
    }
    static fromXlsxFile(path) {
        return startAsPromise(singleton.Delay(() => {
            const wb = new Excel.Workbook();
            return singleton.Bind(wb.xlsx.readFile(path), () => {
                const fswb = toFsWorkbook(wb);
                return singleton.Return(fswb);
            });
        }));
    }
    static fromXlsxStream(stream) {
        return singleton.Delay(() => {
            const wb = new Excel.Workbook();
            return singleton.Bind(wb.xlsx.read(stream), () => singleton.Return(toFsWorkbook(wb)));
        });
    }
    static fromBytes(bytes) {
        return singleton.Delay(() => {
            const wb = new Excel.Workbook();
            const uint8 = new Uint8Array(bytes);
            return singleton.Bind(wb.xlsx.load(uint8.buffer), () => singleton.Return(toFsWorkbook(wb)));
        });
    }
    static toFile(path, wb) {
        const jswb = toJsWorkbook(wb);
        return jswb.xlsx.writeFile(path);
    }
    static toStream(stream, wb) {
        const jswb = toJsWorkbook(wb);
        return jswb.xlsx.write(stream);
    }
    static toBytes(wb) {
        return singleton.Delay(() => {
            const jswb = toJsWorkbook(wb);
            const buffer = jswb.xlsx.writeBuffer();
            return singleton.Return(buffer);
        });
    }
}

export function Xlsx_$reflection() {
    return class_type("FsSpreadsheet.Exceljs.Xlsx", void 0, Xlsx);
}

